import sys
from .pyKaraoke import cli
def run():
    cli()